package com.example.posting.Prevalent;


import com.example.posting.Model.Users;

public class Prevalent
{
    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";
}
