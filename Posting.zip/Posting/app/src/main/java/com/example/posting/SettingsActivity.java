package com.example.posting;

public class SettingsActivity {
}
